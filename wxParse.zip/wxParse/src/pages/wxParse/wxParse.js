import Taro, { Component } from '@tarojs/taro'
import { View } from '@tarojs/components'

import WxParse from '../../components/wxParse/wxParse'

export default class wxParse extends Component {
  config = {
    navigationBarBackgroundColor: '#ffffff',
    navigationBarTextStyle: 'black',
    navigationBarTitleText: 'WxParse 使用示例',
    backgroundColor: '#eeeeee',
    backgroundTextStyle: 'light'
  }

  componentDidMount() {
    const article = '<section data-role="outer" label="Powered by 135editor.com" style="font-size:16px;"><section data-role="outer" label="Powered by 135editor.com" style="font-size:16px;"><section class="_135editor" data-tools="135编辑器" data-id="94017"><section style="padding: 10px; box-sizing: border-box;"><section style="box-shadow:rgb(221,221,221) 0px 0px 6px;background:url(https://image2.135editor.com/cache/remote/aHR0cHM6Ly9tbWJpei5xbG9nby5jbi9tbWJpel9wbmcvN1FSVHZrSzJxQzRicFNRaWNwcU1OODJnN0F0NTNEUUxCVHE2dmRkS09iczFzc3g4RDFXUnFVOTl6aWNzZW1hMDNreDY5ODhMTVlvRmljV0RPUERoZG5mTmcvMD93eF9mbXQ9cG5n);background-size: cover;"><section style="background: url(https://image2.135editor.com/cache/remote/aHR0cHM6Ly9tbWJpei5xbG9nby5jbi9tbWJpel9wbmcvN1FSVHZrSzJxQzRicFNRaWNwcU1OODJnN0F0NTNEUUxCeThSTmljRHFzaWNhOEE5ajN6T0dRZE12Mm80dHByeDBUV3puaG5NMHJ6ZUxkWWc1WkV6Z29wMEEvMD93eF9mbXQ9cG5n)no-repeat;background-position:left bottom;background-size: 40%;"><section class="135brush" data-brushtype="text" style="font-size: 14px; text-align: justify; letter-spacing: 1.5px; line-height: 1.75em; padding: 2em 1em 2em 2em; color: rgb(142, 179, 189); box-sizing: border-box;"><p>我要在最细的雨中 吹出银色的花纹 让所有在场的丁香 都成为你的伴娘 我要张开梧桐的手掌 去接雨水洗脸 让水杉用软弱的笔尖 在风中写下婚约。</p><p style="text-align:right;" align="right">— — 顾城 《南国之秋》</p></section></section></section></section></section><section class="_135editor" data-tools="135编辑器" data-id="94192"><section style="padding: 1em 0px; box-sizing: border-box;"><section style="background:#effafe;box-shadow: 0px 0px 5px rgb(212,212,212);"><section style="background: url(https://image2.135editor.com/cache/remote/aHR0cHM6Ly9tbWJpei5xbG9nby5jbi9tbWJpel9wbmcvN1FSVHZrSzJxQzdid1hxM2liRFFqSzdmVGtPNzVGYkExQ3pma2dSU3FtV1VDeXVhcFpYa3NrZ09NR0owQldoR0dJWlNrRWVjV042ZjZITGdpYWViUEF1dy8wP3d4X2ZtdD1wbmc=)no-repeat;background-size:100% ;background-position:bottom ;"><section data-autoskip="1" class="135brush" style="font-size: 14px; text-align: justify; letter-spacing: 1.5px; line-height: 1.75em; color: rgb(63, 62, 63); padding: 1em 1em 2.5em; box-sizing: border-box;"><p>行走在岁月的小巷，听风，读雨，夜色空寂，一切烟云，皆会慢慢散去，光阴眷顾，你我默默相依，慢慢老去，红尘若可安好，便可不悲不喜，不离不弃，情真意切，绵绵无期。</p></section></section></section></section></section><p><br></p></section></section>'
    WxParse.wxParse('article', 'html', article, this.$scope, 5)
  }

  render() {
    return (
      <View>
        <import src='../../components/wxParse/wxParse.wxml' />
        <template is='wxParse' data='{{wxParseData:article.nodes}}'/>
      </View>
    )
  }
}
